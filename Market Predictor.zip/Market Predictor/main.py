import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input
from tensorflow.keras.callbacks import EarlyStopping
import matplotlib.pyplot as plt

# Fetching data
nasdaq_data = yf.Ticker("^IXIC")
data = nasdaq_data.history(period="5y")

# Use only the 'Close' prices
close_prices = data['Close'].values.reshape(-1, 1)

# Splitting data into training and testing sets
train_size = int(len(close_prices) * 0.8)
train_data = close_prices[:train_size, :]
test_data = close_prices[train_size - 60:, :]

# Data preprocessing for training data
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_train_data = scaler.fit_transform(train_data)

# Preparing data for LSTM model
X_train, y_train = [], []
for i in range(60, len(scaled_train_data)):
    X_train.append(scaled_train_data[i-60:i, 0])
    y_train.append(scaled_train_data[i, 0])
X_train, y_train = np.array(X_train), np.array(y_train)
X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))

# Building Enhanced LSTM Model
model = Sequential()
model.add(Input(shape=(60, 1)))  # Input layer
model.add(LSTM(units=100, return_sequences=True))
model.add(Dropout(0.2))
model.add(LSTM(units=100))
model.add(Dropout(0.2))
model.add(Dense(units=1))

# Compiling the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Early Stopping Callback
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# Training the model with early stopping and validation split
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_split=0.2, callbacks=[early_stopping])

# Preparing test data
scaled_test_data = scaler.transform(test_data)
X_test, y_test = [], []
for i in range(60, len(scaled_test_data)):
    X_test.append(scaled_test_data[i-60:i, 0])
    y_test.append(scaled_test_data[i, 0])
X_test, y_test = np.array(X_test), np.array(y_test)
X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

# Model evaluation and prediction
predicted_stock_price = model.predict(X_test)
predicted_stock_price = scaler.inverse_transform(predicted_stock_price)

# The actual test stock prices
real_stock_price = scaler.inverse_transform(y_test.reshape(-1, 1))

# Plotting the results
plt.figure(figsize=(10,6))
plt.plot(real_stock_price, color='red', label='Real Stock Price')
plt.plot(predicted_stock_price, color='blue', label='Predicted Stock Price')
plt.title('Stock Price Prediction')
plt.xlabel('Time')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

# Future prediction setup
num_days_to_predict = 30  # Number of days you want to predict into the future
last_60_days_data = scaled_train_data[-60:]
X_future = np.array([last_60_days_data])
X_future = X_future.reshape((X_future.shape[0], X_future.shape[1], 1))

# Predict future stock prices for the next 30 days
predicted_future_prices = []
for _ in range(num_days_to_predict):
    future_price = model.predict(X_future)
    predicted_future_prices.append(future_price[0, 0])
    X_future = np.append(X_future[:, 1:, :], [[future_price[0]]], axis=1)

predicted_future_prices = np.array(predicted_future_prices).reshape(-1, 1)
predicted_future_prices = scaler.inverse_transform(predicted_future_prices)

# Plotting the future predictions
plt.figure(figsize=(10, 6))
plt.plot(range(num_days_to_predict), predicted_future_prices, color='green', label='Predicted Future Prices')
plt.title('Future Stock Price Predictions for Next {} Days'.format(num_days_to_predict))
plt.xlabel('Days into the Future')
plt.ylabel('Predicted Stock Price')
plt.legend()
plt.show()
